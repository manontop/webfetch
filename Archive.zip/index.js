var express = require('express');
var request = require('request');
//const path = require('path');
const router = express.Router();
var app = express();

//add the router
app.use(express.static('View'));
//Store all HTML files in view folder.
app.use(express.static('Script'));
//Store all JS and CSS in Scripts folder.

app.get('/api', function(req, res){
    url = "https://shoppy.gg/api/v1/public/seller/winboyshop";
    request(url, function(error, response, html){
        res.send(response)
    })
})

app.get('/', function (req, res) {
    res.sendFile('index.html');
});


app.use('/', router);
app.listen(3000, function () {
  console.log('listening on port 3000!');
});