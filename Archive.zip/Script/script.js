var app = angular.module("myApp", []);
app.controller("prodCtrl", function($scope, $http, $window) {
  window.onload = function() {
    console.log("fetching");
    $http 
      .get(
        "http://127.0.0.1:3000/api"
      )
      .then(function(response) {
        //console.log("response", response);
        json = JSON.parse(response.data.body)
        console.log(json)
        $scope.prods = json.user.products;
        $scope.prods.forEach(prod => {
          if (prod.stock == 9223372036854776000) {
            prod.stock = "--";
          }
          prod.url = "https://shoppy.gg/product/" + prod.id;
        });
      });
      
    
  }
     
    
    
  $scope.stock = false;
  $scope.price = false;
  $scope.both = false;
  $scope.toggle = function(option) {
    console.log(option);
    if (option === "1") {
      $scope.stock = true;
      $scope.price = false;
      $scope.both = false;
    } else if (option === "2") {
      $scope.stock = false;
      $scope.price = true;
      $scope.both = false;
    } else {
      $scope.stock = false;
      $scope.price = false;
      $scope.both = true;
    }
  }
  
  $scope.sortType     = 'name'; // set the default sort type
  $scope.sortReverse  = false;  // set the default sort order
  $scope.searchProd   = '';     // set the default search/filter term
  
  $scope.changeSort = function(type) {
    $scope.sortType = type;
    $scope.sortReverse  = !$scope.sortReverse;
  }
  
   $scope.copyName = function(prod) {
    document.addEventListener('copy', (e) => {
      e.clipboardData.setData('text/plain', (prod.title));
      e.preventDefault();
      document.removeEventListener('copy', null);
    });
    document.execCommand('copy');
   }
  
//     EDIT BUTTON CODE
  
    $scope.copyEdit = function(prod) {
    document.addEventListener('copy', (e) => {
      e.clipboardData.setData('text/plain', (prod.url + '/edit'));
      e.preventDefault();
      document.removeEventListener('copy', null);
    });
    document.execCommand('copy');
   }

   $scope.openEdit = function(prod) {
    $window.open(prod.url.replace('product', 'products') + '/edit');
   }
    
  
  
  // find and replace on page loa


  
  //https://shoppy.gg/product/
  
  
});


// Date and time funtion:
var today = new Date();
var day = today.getDay();
var daylist = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
var hour = today.getHours();
var min = today.getMinutes();

var suffix = (hour >= 12)? " PM" : " AM";
hour = (hour >= 12)? hour - 12 : hour;

if (hour === "0" && suffix === " PM"){
  if(min === "0" && sec === "0") {
    hour = 12;
    suffix = " Noon";
  }
} 
else if (hour === "0" && suffix === " AM") {
  if(min === "0" && sec === "0") {
    hour = 12;
    suffix = " Midnight";
  }
}

var todayHTML = document.getElementById("todayHTML");
//console.log(todayHTML)
var timeHTML = document.getElementById("timeHTML");

todayHTML.innerText = "Last refresh: " + daylist[day] + " " + hour + ":" + min + " " + suffix;